//
//  ViewController.h
//  TestWebView
//
//  Created by ramonqlee on 2/11/15.
//  Copyright (c) 2015 iDreems. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

-(IBAction)openWebview:(id)sender;


@end

